This program is the GoFish program for EE312 Lab06
by Matthew Hall and PoChih Chen

on unzipping, one can just run the ./gofish program and the game will be played into gofish?results.txt

you can also make to build the program, but no arguments are needed. The program will play the game gofish with a random shuffled deck until a winner has been decided.


4/12/19
